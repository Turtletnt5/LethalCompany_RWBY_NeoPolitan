# RWBY_NeoPolitan v0.2.1
### Add NeoPolitan from RWBY as a skin 

This is a mod that adds NeoPolitan from RWBY as a suit option.

The model is made by tidiestflyer 
The mod utilizes MoreSuits by x753 and ModelReplacmentAPI by BunyaPineTree.
The physiscs are from unityJigglePhysics by naelstrof

MoreSuits: https://github.com/x753/Lethal-Company-More-Suits

ModelReplacementAPI: https://github.com/BunyaPineTree/LethalCompany_ModelReplacementAPI

Model: https://www.deviantart.com/tidiestflyer/art/Rwby-Neo-3d-model-721580341

Physics: https://github.com/naelstrof/UnityJigglePhysics

## Instructions
- Place contents in `bepinex/plugins` folder. Ensure that ModelReplacementAPI and MoreSuits is also installed. 

## Changelog
	- v0.2.1
		- Fixed Body physics
	- v0.2.0
		- Added physics to character hair, clothes and body
		- Changed rack suit accent color to pink
	- v0.1.1
		- Fixed moresuits replacment path
	- v0.1.0
		- Release
	