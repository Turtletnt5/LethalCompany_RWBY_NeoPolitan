# RWBY_NeoPolitan v0.1.0
### Add NeoPolitan from RWBY as a skin 


## Instructions
- Place contents in `bepinex/plugins` folder. Ensure that ModelReplacementAPI is also installed. 

## Changelog
	- v0.1.0
		- Release